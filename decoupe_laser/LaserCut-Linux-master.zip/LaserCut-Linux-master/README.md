# LaserCut
An installer for the LaserCut software on linux and macOS

The content of Lasercut's installation folder should be placed in ` LaserCut53/LaserCut/ `
